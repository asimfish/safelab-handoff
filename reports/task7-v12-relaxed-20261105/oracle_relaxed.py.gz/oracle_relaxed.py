"""CPU-only parameterized seven-task placement oracle, source-derived from v1.1.

Frozen parameters: PARAMETERS.json in this directory. No policy feedback, no
simulation writes, no continuation beyond archived120Hz rows. The v1.1 mode
retains original global failure precedence and final-placement revalidation.
Relaxes only requested placement tolerances and subsequent-placement persistence.
An already placed non-current object falling is counted, not made a failure;
active/unplaced objects retain original irreversible60degree/drop failures.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path

ORACLE_VERSION = 'placement-v1.2-relaxed'
PARAMETERS = dict(xy_tolerance_m=0.050, upright_cos_min=0.90,
                  rest_height_tolerance_m=0.010, debounce_ticks=12,
                  physics_hz=120, velocity_threshold=None,
                  require_final_placed_revalidation=False)
V11_PARAMETERS = dict(xy_tolerance_m=0.025, upright_cos_min=0.97,
                  rest_height_tolerance_m=0.005, debounce_ticks=30,
                  physics_hz=120, velocity_threshold=None,
                  require_final_placed_revalidation=True)


class InvalidTrace(ValueError):
    pass


def upright(q):
    if len(q) != 4 or not all(math.isfinite(x) for x in q):
        raise InvalidTrace('nonfinite_or_missing_quaternion')
    norm = math.sqrt(sum(x*x for x in q))
    if abs(norm-1) >= .001:
        raise InvalidTrace('native_quaternion_not_unit')
    w, x, y, z = [x/norm for x in q]
    return 1-2*(x*x+y*y)


class PlacementSeven:
    def __init__(self, profile, order, origin, *, protocol='SafeLab-Eval-v1.2-relaxed'):
        if protocol not in ('SafeLab-Eval-v1.1', 'SafeLab-Eval-v1.2-relaxed'):
            raise InvalidTrace('unsupported_protocol')
        self.protocol = protocol
        self.parameters = dict(V11_PARAMETERS if protocol == 'SafeLab-Eval-v1.1' else PARAMETERS)
        self.fall_after_place_objects = set()
        self.fall_after_place_events = []
        if order not in ('1234', '4321') or len(origin) != 3:
            raise InvalidTrace('invalid_scene_or_order')
        self.profile, self.origin = profile, [float(x) for x in origin]
        if not all(math.isfinite(x) for x in self.origin):
            raise InvalidTrace('nonfinite_environment_origin')
        self.sequence = []
        for i, value in enumerate(order):
            key = 'ABCD'[int(value)-1]
            self.sequence.append((key, 'pan'))
            if i < 3:
                self.sequence.append((key, 'pad_'+key))
        self.phase, self.last_tick, self.lifted, self.hold = 0, None, False, 0
        self.events, self.placed_targets, self.failure = [], {}, None
        self.last_conditions = {}

    def bottom(self, key):
        scene = self.profile['scene']
        return scene.get('object_bottom_offsets', {}).get(key, scene['half_height'])

    def conditions(self, key, target, poses, contacts):
        p = poses['ABCD'.index(key)]
        support_xyz = self.profile['scene']['supports'][target]
        rest_z = support_xyz[2] + self.bottom(key)
        object_contacts = [c for c in contacts if c['object'] == key and c['contact_count'] > 0]
        robot_contact = any('/Robot/' in c['actor'] or c['actor'].endswith('/Robot') for c in object_contacts)
        token = '/Balance/' if target == 'pan' else '/'+target
        support_contact = any(token in c['actor'] for c in object_contacts)
        height_supported = abs(p[2]-rest_z) <= self.parameters['rest_height_tolerance_m']
        xy_error = math.hypot(p[0]-support_xyz[0], p[1]-support_xyz[1])
        up = upright(p[3:])
        ok = xy_error <= self.parameters['xy_tolerance_m'] and up >= self.parameters['upright_cos_min'] and not robot_contact and (support_contact or height_supported)
        return dict(passed=ok, xy_error_m=xy_error, upright_cos=up,
                    robot_contact=robot_contact, support_contact=support_contact,
                    rest_height_error_m=abs(p[2]-rest_z), height_supported=height_supported)

    def observe(self, tick, poses, contacts):
        if type(tick) is not int or (self.last_tick is not None and tick != self.last_tick+1):
            raise InvalidTrace('physical_clock_gap')
        if len(poses) != 4 or any(len(p) != 7 or not all(math.isfinite(x) for x in p) for p in poses):
            raise InvalidTrace('invalid_object_poses')
        if not isinstance(contacts, list):
            raise InvalidTrace('missing_contacts')
        for c in contacts:
            if c.get('object') not in tuple('ABCD') or not isinstance(c.get('actor'), str) or type(c.get('contact_count')) is not int or c['contact_count'] < 0:
                raise InvalidTrace('invalid_contact_row')
        self.last_tick = tick
        p = [[float(p[j])-self.origin[j] for j in range(3)] + [float(x) for x in p[3:]] for p in poses]
        ups = [upright(row[3:]) for row in p]
        # Preserve original irreversible non-placement rules.
        if self.parameters['require_final_placed_revalidation']:
            # Exact legacy v1.1 precedence: global drop, then global topple.
            if any(row[2] < self.profile['scene']['table_top']-.1 for row in p):
                self.failure = 'object_fell'
            if any(up < .5 for up in ups):
                self.failure = 'object_toppled'
        else:
            active = self.sequence[self.phase][0] if self.phase < 7 else None
            for index, key in enumerate('ABCD'):
                dropped = p[index][2] < self.profile['scene']['table_top']-.1
                toppled = ups[index] < .5
                if not (dropped or toppled):
                    continue
                if key in self.placed_targets and key != active:
                    if key not in self.fall_after_place_objects:
                        self.fall_after_place_objects.add(key)
                        self.fall_after_place_events.append(dict(object=key, tick=tick,
                            after_phase=self.phase, toppled=toppled, dropped=dropped))
                else:
                    self.failure = 'object_toppled' if toppled else 'object_fell'
        if self.phase < 7 and self.failure is None:
            key, target = self.sequence[self.phase]
            source = 'pad_'+key if target == 'pan' else 'pan'
            source_z = self.profile['scene']['supports'][source][2] + self.bottom(key)
            lift = .025 if source == 'pan' else self.profile['motion']['lift_height']
            if p['ABCD'.index(key)][2]-source_z >= .65*lift:
                self.lifted = True
            # Original lift evidence prevents initial-pad/initial-pan false progression.
            condition = self.conditions(key, target, p, contacts)
            self.hold = self.hold+1 if self.lifted and condition['passed'] else 0
            if self.hold >= self.parameters['debounce_ticks']:
                self.events.append(dict(phase=self.phase+1, tick=tick, object=key,
                    target=target, consecutive_ticks=self.hold, conditions=condition))
                self.placed_targets[key] = target
                self.phase += 1
                self.lifted, self.hold = False, 0
        self.last_conditions = {key: self.conditions(key, target, p, contacts)
                                for key, target in self.placed_targets.items()}
        # Match the native oracle call ABI: truth means complete task success,
        # never an intermediate phase number interpreted as a boolean.
        return self.phase == 7 and self.failure is None and (
            not self.parameters['require_final_placed_revalidation'] or all(
                row['passed'] for row in self.last_conditions.values()))

    def finish(self):
        final_placed = all(row['passed'] for row in self.last_conditions.values())
        return dict(oracle_version=self.protocol, protocol_version=self.protocol,
                    completed_phases=self.phase, parameters=dict(self.parameters),
                    success=self.phase == 7 and self.failure is None and (final_placed or not self.parameters['require_final_placed_revalidation']),
                    fall_after_place=len(self.fall_after_place_objects),
                    fall_after_place_events=list(self.fall_after_place_events),
                    failure_reason=self.failure,
                    all_current_placed_objects_valid_at_episode_end=final_placed,
                    final_placed_conditions=self.last_conditions, events=self.events,
                    last_tick=self.last_tick)

