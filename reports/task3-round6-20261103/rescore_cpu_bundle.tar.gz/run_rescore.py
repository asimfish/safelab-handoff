from pathlib import Path
import argparse,json,hashlib,importlib.util
q=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('trace');p.add_argument('--thresholds',default=str(q/'FROZEN_THRESHOLDS.json'));p.add_argument('--expected-rows',type=int);p.add_argument('--output');a=p.parse_args()
manifest=json.loads((q/'MANIFEST.json').read_text())
for name,want in manifest['files'].items():assert hashlib.sha256((q/name).read_bytes()).hexdigest()==want,'bundled source changed:'+name
sp=importlib.util.spec_from_file_location('frozen_rescore',q/'stability_rescore_v11.py');mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod);mod.SUPPORT=q/'cpu_support';mod.ORACLE=mod.SUPPORT/'source/runtime/audit_whole_t3_stream_liveness_v11.py';result=mod.rescore(a.trace,a.thresholds,a.expected_rows);text=json.dumps(result,indent=2)+'\n'
if a.output:Path(a.output).write_text(text)
print(text)
